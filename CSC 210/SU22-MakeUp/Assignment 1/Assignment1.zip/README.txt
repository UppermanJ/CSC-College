Program:  Assignment1.cpp
Author:  Josiah Upperman
Input File:  myFile.txt
Name of IDE/compiler used to create the program, for example:  built and compiled using Microsoft Visual Studio Code  

How to run the program:

Execute in Dev-C++:  Open Assignment1.cpp
                     Select Compile and Run
                     When program asks for file name, enter:  TestData (The prompt will clarify that file extensions are handled by the runtime enviornment)
                     
Any special instructions needed for execution or placement of files (folders):
I used the gdb compiler and had the files in the same folder.
                     


