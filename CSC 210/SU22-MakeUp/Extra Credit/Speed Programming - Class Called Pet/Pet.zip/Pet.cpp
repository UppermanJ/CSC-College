#include "Pet.hpp"

int main()
{
    Pet pet(PetType DOG, "Fido");
    cout << pet.feed() << endl;
    cout << pet.speak() << endl;
    return 0;
}