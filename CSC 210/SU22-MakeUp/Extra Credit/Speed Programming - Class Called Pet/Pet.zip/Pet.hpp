#ifndef PET_HPP
#define PET_HPP
#include <iostream>
#include <string>


using namespace std;

enum PetType {DOG, CAT, BIRD, FISH, OTHER};
enum foodType {MEAT, FISH, OTHERFOOD};

class Pet
{
private:
    string species, name;
    bool hungry = false;

public:
    Pet(string, string);
    ~Pet();
    string feed(Pet &pet);
    string speak();
};

Pet::Pet(string species, string name)
{
    this->species = species;
    this->name = name;
}


Pet::~Pet()
{
}

Pet::feed(Pet &pet)
{
    if (hungry)
    {
        if(PetType == DOG)
        {
            cout << "Woof!" << endl;
        }
        else if(PetType == CAT)
        {
            cout << "Meow!" << endl;
        }
        else if(PetType == BIRD)
        {
            cout << "Tweet!" << endl;
        }
        else if(PetType == FISH)
        {
            cout << "Glub!" << endl;
        }
        else
        {
            cout << "I don't know what sound this animal makes!" << endl;
        }
        hungry = false;
        return "Thanks!";
    }
    else
    {
        return "I'm not hungry!";
    }
    return "";
}

Pet::speak()
{
    if
    return "";
}

#endif